//============================================================================
// Name        : ProjTwoBst.cpp
// Author      : Orion J. Murray
// Version     : 1.0
// Copyright   : Copyright � 2017 SNHU COCE
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// Forward declarations
double strToDouble(string str, char ch);

// Define a structure to hold course information
struct Course {
    string courseNumber;
    string courseName;
    vector<string> prerequisites;
};

// Internal structure for tree node
struct Node {
    Course course;
    Node* left;
    Node* right;

    // Default constructor
    Node() {
        left = nullptr;
        right = nullptr;
    }

    // Initialize with a course
    Node(Course aCourse) :
        Node() {
        course = aCourse;
    }
};

//============================================================================
// Binary Search Tree class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */
class BinarySearchTree {
private:
    Node* root;
    void inOrder(Node* node);
    Course search(Node* node, string courseNumber);

public:
    BinarySearchTree() : root(nullptr) {}
    void inOrderTraversal();
    void load(Course course);
    Course search(string courseNumber);
};

void BinarySearchTree::load(Course course) {
    Node* newNode = new Node(course);

    // If the tree is empty
    if (root == nullptr) {
        root = newNode;
        return;
    }

    Node* current = root;
    Node* parent = nullptr;

    while (current != nullptr) {
        parent = current;
        if (course.courseNumber < current->course.courseNumber) {
            current = current->left;
        }
        else {
            current = current->right;
        }
    }

    if (course.courseNumber < parent->course.courseNumber) {
        parent->left = newNode;
    }
    else {
        parent->right = newNode;
    }
}

// Sort courses and prerequisites
void BinarySearchTree::inOrder(Node* node) {
    if (node) {
        inOrder(node->left);
        cout << node->course.courseNumber << ": " << node->course.courseName << endl;
        for (auto& prerequisite : node->course.prerequisites) {
            cout << "Prerequisite: " << prerequisite << endl;
        }

        cout << "\n";

        inOrder(node->right);
    }
}
//Helper func to allow lowercase entries to find course information
string toLower(const string& input) {
    string output = input;
    transform(output.begin(), output.end(), output.begin(), ::tolower);
    return output;
}

// Find course information
Course BinarySearchTree::search(Node* node, string courseNumber) {
    string lowerCaseInput = toLower(courseNumber);
    string lowerCaseNodeCourseNumber = toLower(node->course.courseNumber);

    if (!node) return Course();
    if (lowerCaseInput == lowerCaseNodeCourseNumber) return node->course;
    if (lowerCaseInput < lowerCaseNodeCourseNumber) return search(node->left, courseNumber);
    return search(node->right, courseNumber);
}

// Print sample schedule
void BinarySearchTree::inOrderTraversal() {
    inOrder(root);
}

//Search course information
Course BinarySearchTree::search(string courseNumber) {
    return search(root, courseNumber);
}

// Load the course from the CSV
void loadCourses(string csvPath, BinarySearchTree& bst) {
    try {
        csv::Parser file = csv::Parser(csvPath);
        for (unsigned int i = 0; i < file.rowCount(); i++) {
            Course course;
            course.courseNumber = file[i]["courseNumber"];
            course.courseName = file[i]["courseName"];

            // Assuming the prerequisites could be empty
            if (!file[i]["preReq1"].empty()) {
                course.prerequisites.push_back(file[i]["preReq1"]);
            }
            if (!file[i]["preReq2"].empty()) {
                course.prerequisites.push_back(file[i]["preReq2"]);
            }

            bst.load(course);
        }
    }
    catch (csv::Error& e) {
        std::cerr << e.what() << std::endl;
    }
}


    /**
     * Simple C function to convert a string to a double
     * after stripping out unwanted char
     *
     * credit: http://stackoverflow.com/a/24875936
     *
     * @param ch The character to strip out
     */
    double strToDouble(string str, char ch) {;
        str.erase(remove(str.begin(), str.end(), ch), str.end());
        return atof(str.c_str());
    }

    /**
     * The one and only main() method
     */
    int main() {
        BinarySearchTree courses;
        int option;
        string courseNumber, filename;

        cout << "Welcome to the course planner." << endl;

        do {
            cout << "\n1. Load data structure." << endl;
            cout << "2. Print course list." << endl;
            cout << "3. Print course." << endl;
            cout << "9. Exit" << endl;
            cout << "What would you like to do? ";
            cin >> option;

            switch (option) {
            case 1: {
                cout << "\nEnter the file name you wish to load: ";
                cin >> filename;
                loadCourses(filename, courses);
                cout << "Finished!" << endl;
                break;
            }

            case 2: {
                cout << "\nHere is a sample schedule:" << endl;
                courses.inOrderTraversal();
                break;
            }

            case 3: {
                cout << "\nWhat course do you want to know about? ";
                cin >> courseNumber;
                Course course = courses.search(courseNumber);
                if (course.courseNumber != "") {
                    cout << course.courseNumber << ": " << course.courseName << endl;
                    if (!course.prerequisites.empty()) {
                        cout << "Prerequisites:" << endl;
                        for (const string& prereq : course.prerequisites) {
                            cout << "- " << prereq << endl;
                        }
                    }
                }
                else {
                    cout << "Course not found!" << endl;
                }
                break;
            }

            case 9: {
                cout << "\nThank you for using the course planner!" << endl;
                break;
            }

            default:
                cout << "\nInvalid option. Please try again." << endl;
            }
        } while (option != 9);

        return 0;
    }